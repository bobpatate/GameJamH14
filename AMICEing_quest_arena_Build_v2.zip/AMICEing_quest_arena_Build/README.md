Nom-du-jeu
==========

A-Mice-ing Quest: Arena
Styles: RPG, comp�tition

Contr�les:
Manette: Stick gauche pour bouger, A pour ramasser/parler au marchand
Clavier: Joueur 1: Wasd pour bouger, e pour ramasser/parler au marchand
		Joueur 2: fl�ches pour bouger, ctrl pour ramasser/parler au marchand

Gameplay: 
Ramassez des ressources, une fois que vous en avez plus de 4, allez les donner au marchand (le chat) pour obtenir des objets! (et vous faire soigner)
Les enemis avec une aura de la m�me couleur que vous sont alli�s, les autres sont des enemis.
Les combats sont automatiques, esp�rez avoir de l'�quipement assez fort pour vous en sortir!
Le jeu se termine quand vous avez battu le marchand de l'�quipe adverse.
Diff�rentes combinaisons de ressources am�nent le marchand a vous donner diff�rents objets!
Plus vous vous �loignez de votre base plus les enemis sont fort, et les ressources pr�cieuses!